KaKs_Calculator, Version 3.0 (Nov. 2021)

KaKs_Calculator is a toolkit for calculating selective pressure on both coding
and non-coding sequences. For coding sequences, it integrates several methods to
calculate nonsynonymous (Ka) and synonymous (Ks) substitution rates. Similar to
the Ka/Ks ratio for coding sequences, selection on non-coding sequences can be
quantified as non-coding nucleotide substitution rate (Kn) normalized by
synonymous substitution rate of adjacent coding sequences, viz., Kn/Ks.

bin/: commandline executables on Windows 
examples/: example of axt sequence files 
GUI/: Windows setup application 
src/: source codes

Kaks_Calculator is freely available for academic use only at

	https://ngdc.cncb.ac.cn/biocode/tools/BT000001

Please cite: 

Zhang Z: KaKs_Calculator 3.0: calculating selective pressure on
coding and non- coding sequences. Genomics Proteomics Bioinformatics 2021, under
review.

Wang D, Zhang Y, Zhang Z, Zhu J, Yu J: KaKs_Calculator 2.0: a toolkit
incorporating gamma-series methods and sliding window strategies. Genomics
Proteomics Bioinformatics 2010, 8(1):77-80.

Zhang Z, Li J, Zhao XQ, Wang J, Wong GK, Yu J: KaKs_Calculator: calculating Ka
and Ks through model selection and model averaging. Genomics Proteomics
Bioinformatics 2006, 4(4):259-263.

Please send bugs or advice to Zhang Zhang at zhangzhang@big.ac.cn.

Zhang Zhang, PhD, Professor
National Genomics Data Center (NGDC)
China National Center for Bioinformation (CNCB)
Beijing Institute of Genomics (BIG)
Chinese Academy of Sciences (CAS)

Postal Address:
	1 Beichen West Road, Chaoyang District, Beijing 100101, China

//Last Update: Nov. 25, 2021
